#!/usr/bin/env python

import json
import sys

def is_instance(json):
    return json['type'] == 'aws_instance'

def is_loadbalancer(json):
    return json['type'] == 'aws_lb'

def extract_fauna_tags(attrs):
    replica = attrs.get('tags.FaunaReplica')
    if replica:
        log_slice = attrs['tags.FaunaLogSegment']
        return (log_slice, replica)

def extract_group(attrs):
    return attrs.get('tags.Group')

def extract_bastion_ip(attrs):
    if attrs['tags.Name'] == 'bastion':
        return attrs['public_ip']

with open('../terraform/terraform.tfstate', 'r') as f:
    state = json.load(f)
    groups = {"_meta": {"hostvars": {}}}
    hosts = []
    fauna_replicas = set()

    for module in state["modules"]:
        resources = module["resources"]
        instances = (instance_json for instance_json in resources.values() if
                     is_instance(instance_json))
        for instance in instances:
            attributes = instance['primary']['attributes']
            hostname = attributes['private_ip']
            hosts.append(hostname)
            fauna_tags = extract_fauna_tags(attributes)
            group = extract_group(attributes)
            bastion_ip = extract_bastion_ip(attributes)
            if bastion_ip:
                cmd = '-o ProxyCommand="ssh -W %h:%p -q ec2-user@{0}"'.format(bastion_ip)
                groups['all'] = {'vars': {'ansible_ssh_common_args': cmd}}
            if group:
                if group in groups:
                    groups[group]['hosts'].append(hostname)
                else:
                    groups[group] = {'hosts': [hostname]}

                if not ('vars' in groups[group]):
                    groups[group]['vars'] = {}

            if fauna_tags:
                (log_slice, replica) = fauna_tags
                groups['_meta']['hostvars'][hostname] = {
                    'fauna_replica': replica,
                    'fauna_log_slice': log_slice
                }
                fauna_replicas.add(replica)

        load_balancers = (lb_json for lb_json in resources.values() if
                          is_loadbalancer(lb_json))

        for load_balancer in load_balancers:
            attributes = load_balancer['primary']['attributes']
            name     = attributes['name']
            dns_name = attributes['dns_name']
            if name == 'fauna':
                if 'ledgerserver' in groups:
                    groups['ledgerserver']['vars'] = {'lb_addr': dns_name}
                else:
                    groups['ledgerserver'] = {'vars': {'lb_addr': dns_name},
                                              'hosts': []}
            if name == 'ledger':
                if 'loadserver' in groups:
                    groups['loadserver']['vars'] = {'lb_addr': dns_name}
                else:
                    groups['loadserver'] = {'vars': {'lb_addr': dns_name},
                                            'hosts': []}

    if 'fauna' in groups:
        groups['fauna']['vars']['fauna_replicas'] = list(fauna_replicas)

    groups['hosts'] = hosts
    json.dump(groups, sys.stdout)
