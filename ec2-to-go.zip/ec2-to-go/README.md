EC2 to Go
=========

This is a toy single region aws fauna install. It does however allow you to flex most of faunas capabilities in a single easy to manage package.

Currently the region and availability zones are hard-coded to reside in aws-west-2. You can change this to whatever you hear desires. Important numbers to decide

## CLUSTER SIZE
The total number of instances in the cluster.

## REPLICAS
The number of complete replicas that have a complete copy of the data and sit in a single failure domain. This installer will assume that a subnet corresponds to a distinct failure domain, which in aws land is an AZ. In practice this limits you to three replicas, without multiple regions, which is beyond the scope of this installer. Instances will be split evenly among the replicas (within reason).

## LOG SEGMENTS
The degree of parallelism for accepting transactions to the transaction log. This cannot exceed `min(hosts in replicas)`. It must be at least one.

## Examples

- Small HA setup might have a cluster size of three, with three replicas and one log segment. This means that each node participates in log replication and holds 100% of the data. 
- A larger cluster might have a cluster size of nine with three replicas and one log segment. This means each node holds about a third of the data and each replica has a designated node for participating in log replication.
- A larger cluster with a segmented log might have nine nodes over three replicas with three log segments. This is as above but all nodes would participate in log replication.

General AWS architecture
========================

This is best-practice lite. We have a public and a private subnet per az so that we can avoid ip allocation for anything that shoudn't be contacted directly. One of our public subnets has a NAT gateway for our private subnets to reach the internet, and routing configured for that. We also have a single bastion host for accessing the rest of the fleet. The cluster is spread over our AZs and accessed by an internet facing application loadbalancer which is mapped to our public subnets.

The install process
===================

- terraform creates infrastructure
- ansible provisions the nodes
- ???
- profit

There is one extra bit of legwork required. Ansible installs java and fauna by pulling artifacts off an s3 bucket. It will create instances with the right iam permissions for the bucket but it doesn't create the bucket or push artifacts to it. You need to do that. Unfortunately it currently expects exactly 2.5.3 and the name of the bucket is hardcoded to `fauna-setup` so you'll need to sed that to something sensible. It also expects you use [zulu](https://www.azul.com/downloads/zulu/zulu-linux/) which isn't right either. I'm sure someone will fix that eventually. THIS BUCKET DOES NOT NEED TO BE AND SHOULD NOT BE PUBLICY ACCESSIBLE.

Terraform
=========

First and foremost you _must_ have [AWS credentials](https://www.terraform.io/docs/providers/aws/index.html) for the account under which you want to create the resources. If you have working default credentials for the aws cli, then this will work just fine. Or you can export environment variables. For example:
```
$ export AWS_ACCESS_KEY_ID="anaccesskey"
$ export AWS_SECRET_ACCESS_KEY="asecretkey"
```
If you wish for more detail please see the linked documentation.

There are a terraform few variables that need to be set. You can either set them with environment variables, or you can respond to terraforms interactive prompt. They are as follows:

- `key_name`: the name of a key in ec2 that you would like these instances provisioned with. Without it you will not be able to access the instances.
- `aws_bucket_name`: The name of an aws bucket where the fauna distribution and java rpms can be found.
- `fauna_cluster_size`: The cluster size as above.
- `fauna_replicas`: The number of replicas as above
- `fauna_log_segments`: The number of log segments as above.

To set these such that terraform no longer prompts you something like the following will do the trick
```
export TF_VAR_key_name="KEY"
export TF_VAR_aws_bucket_name="BUCKET"
export TF_VAR_fauna_cluster_size=3
export TF_VAR_fauna_replicas=3
export TF_VAR_fauna_log_segments=1
```
You can get started with a `terraform init` followed by a `terraform apply`. By the end of it you should have some shiny new boxes. If you get iam permissions errors please see your friendly aws admin to get credentials with the relevant permissions.

When you are done with your cluster `terraform destroy` will make it go away.

Ansible
=======

Once terraform has finished provisioning your machine, log into the ec2 console and look for your bastion host and ssh onto it `ssh ec2-user@$ip`. The goal here is twofold: one to get the hostkey trusted by you and two to check for key problems. If at this stage you are being denied then please add whatever key you told terraform to use to your ssh-agent. You are using one aren't you? If you want to elect the way of pain try specifying the key with `ssh -i /path/to/key ec2-user@$ip`. If that works continue on (but reconsider your life choices). Switch to the ansible directory. If you are an agentless heathen be sure to add `--private-key /path/to/key` to your invocation.

```
ansible-playbook -i aws.py playbook.yml
```

Now enjoy a cuppa while ansible does it work. At the end of it you should have a shiny working cluster. This can be verified with `curl http://$aws_lb/ping`. It should return 200. If it's anything else contact Brandon. He'll be happy to help.
